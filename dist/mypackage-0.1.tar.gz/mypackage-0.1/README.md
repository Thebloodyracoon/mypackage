# mypackage
this library was creatd as an axample of how to publish you own python package.

# How to install
...